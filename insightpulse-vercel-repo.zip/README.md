# InsightPulse (Static, Vercel-ready)

One-file static site. Deploy steps:

1. Create a new GitHub repo (empty).
2. Upload these files: `index.html`, `vercel.json`, `og-image.png`.
3. Go to https://vercel.com/new -> Import GitHub -> select this repo -> Deploy.

- No build step required.
- Framework: "Other".
